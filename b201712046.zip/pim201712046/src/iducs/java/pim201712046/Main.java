package iducs.java.pim201712046;

import iducs.java.pim201712046.controller.MemberController;

public class Main {

    public static void main(String[] args) {
        MemberController memberController = new MemberController();
        memberController.dispatch();
    }
}